package com.zybooks.inventoryapp_corinaprado

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val inventoryList: List<InventoryItem>,
    private val onDeleteClick: (InventoryItem) -> Unit,
    private val onIncreaseClick: (InventoryItem) -> Unit,
    private val onDecreaseClick: (InventoryItem) -> Unit
) : RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder>() {

    class InventoryViewHolder(view: View)
        : RecyclerView.ViewHolder(view) {

        val itemName: TextView =
            view.findViewById(R.id.textItemName)

        val quantity: TextView =
            view.findViewById(R.id.textQuantity)

        val increaseButton: Button =
            view.findViewById(R.id.buttonIncrease)

        val decreaseButton: Button =
            view.findViewById(R.id.buttonDecrease)

        val deleteButton: Button =
            view.findViewById(R.id.buttonDelete)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): InventoryViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_inventory,
                parent,
                false
            )

        return InventoryViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: InventoryViewHolder,
        position: Int
    ) {

        val item = inventoryList[position]

        holder.itemName.text = item.itemName
        holder.quantity.text = item.quantity.toString()

        holder.increaseButton.setOnClickListener {
            onIncreaseClick(item)
        }

        holder.decreaseButton.setOnClickListener {
            onDecreaseClick(item)
        }

        holder.deleteButton.setOnClickListener {
            onDeleteClick(item)
        }

    }

    override fun getItemCount(): Int {
        return inventoryList.size
    }
}