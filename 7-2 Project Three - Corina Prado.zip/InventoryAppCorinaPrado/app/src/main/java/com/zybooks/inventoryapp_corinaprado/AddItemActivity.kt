package com.zybooks.inventoryapp_corinaprado

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class AddItemActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper

    private lateinit var editItemName: EditText
    private lateinit var editQuantity: EditText
    private lateinit var buttonSaveItem: Button

    private lateinit var buttonSmsPermission: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_add_item)

        databaseHelper = DatabaseHelper(this)

        editItemName = findViewById(R.id.editItemName)
        editQuantity = findViewById(R.id.editQuantity)
        buttonSaveItem = findViewById(R.id.buttonSaveItem)
        buttonSmsPermission =
            findViewById(R.id.buttonSmsPermission)

        buttonSaveItem.setOnClickListener {

            val itemName =
                editItemName.text.toString().trim()

            val quantityText =
                editQuantity.text.toString().trim()

            if (itemName.isEmpty() || quantityText.isEmpty()) {

                Toast.makeText(
                    this,
                    "Please enter item information",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                val quantity = quantityText.toInt()

                val success =
                    databaseHelper.addInventoryItem(
                        itemName,
                        quantity
                    )

                if (success) {

                    Toast.makeText(
                        this,
                        "Item Added",
                        Toast.LENGTH_SHORT
                    ).show()

                    editItemName.text.clear()
                    editQuantity.text.clear()

                } else {

                    Toast.makeText(
                        this,
                        "Unable to add item",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        buttonSmsPermission.setOnClickListener {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        Manifest.permission.SEND_SMS
                    ),
                    100
                )
            }
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 100) {

            if (
                grantResults.isNotEmpty() &&
                grantResults[0] ==
                PackageManager.PERMISSION_GRANTED
            ) {

                Toast.makeText(
                    this,
                    "SMS Permission Granted",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                Toast.makeText(
                    this,
                    "SMS Permission Denied",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

}