package com.zybooks.inventoryapp_corinaprado

data class InventoryItem(
    val id: Int,
    val itemName: String,
    val quantity: Int
)