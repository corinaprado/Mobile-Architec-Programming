package com.zybooks.inventoryapp_corinaprado

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.telephony.SmsManager


class InventoryActivity : AppCompatActivity() {

    private lateinit var buttonAddItem: Button

    private lateinit var databaseHelper: DatabaseHelper

    private lateinit var recyclerInventory: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_inventory)

        databaseHelper = DatabaseHelper(this)

        buttonAddItem = findViewById(R.id.buttonAddItem)

        recyclerInventory =
            findViewById(R.id.recyclerInventory)

        recyclerInventory.layoutManager =
            LinearLayoutManager(this)

        loadInventory()

        buttonAddItem.setOnClickListener {

            startActivity(
                Intent(
                    this,
                    AddItemActivity::class.java
                )
            )
        }
    }

    private fun loadInventory() {

        recyclerInventory.adapter =
            InventoryAdapter(

                databaseHelper.getInventoryItems(),

                { item ->

                    databaseHelper.deleteInventoryItem(
                        item.id
                    )

                    loadInventory()
                },

                { item ->

                    databaseHelper.updateQuantity(
                        item.id,
                        item.quantity + 1
                    )

                    loadInventory()
                },

                { item ->

                    if (item.quantity > 0) {

                        val newQuantity =
                            item.quantity - 1

                        databaseHelper.updateQuantity(
                            item.id,
                            newQuantity
                        )

                        if (newQuantity == 0) {
                            sendLowInventoryAlert()
                        }

                        loadInventory()

                        loadInventory()
                    }
                }
            )
    }

    override fun onResume() {
        super.onResume()

        loadInventory()
    }

    private fun sendLowInventoryAlert() {

        try {

            val smsManager =
                SmsManager.getDefault()

            smsManager.sendTextMessage(
                "5551234567",
                null,
                "Inventory Alert: Item quantity has reached zero.",
                null,
                null
            )

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }

}