package com.zybooks.inventoryapp_corinaprado

import android.content.Context
import android.database.Cursor
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "inventory.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {

        val createUsersTable = """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT
            )
        """.trimIndent()

        val createInventoryTable = """
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_name TEXT,
                quantity INTEGER
            )
        """.trimIndent()

        db.execSQL(createUsersTable)
        db.execSQL(createInventoryTable)
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS inventory")
        onCreate(db)

    }
    fun addUser(username: String, password: String): Boolean {

        val db = writableDatabase

        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }

        val result = db.insert("users", null, values)

        return result != -1L
    }
    fun validateUser(
        username: String,
        password: String
    ): Boolean {

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )

        val exists = cursor.count > 0

        cursor.close()

        return exists
    }

    fun addInventoryItem(
        itemName: String,
        quantity: Int
    ): Boolean {

        val db = writableDatabase

        val values = ContentValues().apply {
            put("item_name", itemName)
            put("quantity", quantity)
        }

        val result = db.insert(
            "inventory",
            null,
            values
        )

        return result != -1L
    }

    fun deleteInventoryItem(id: Int) {

        val db = writableDatabase

        db.delete(
            "inventory",
            "id=?",
            arrayOf(id.toString())
        )
    }

    fun updateQuantity(
        id: Int,
        newQuantity: Int
    ) {

        val db = writableDatabase

        val values = ContentValues().apply {
            put("quantity", newQuantity)
        }

        db.update(
            "inventory",
            values,
            "id=?",
            arrayOf(id.toString())
        )
    }


    fun getAllInventoryItems(): String {

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM inventory",
            null
        )

        val builder = StringBuilder()

        while (cursor.moveToNext()) {

            val itemName =
                cursor.getString(
                    cursor.getColumnIndexOrThrow("item_name")
                )

            val quantity =
                cursor.getInt(
                    cursor.getColumnIndexOrThrow("quantity")
                )

            builder.append(
                "$itemName - Quantity: $quantity\n"
            )
        }

        fun updateQuantity(
            itemName: String,
            quantity: Int
        ) {
            val db = writableDatabase

            val values = ContentValues().apply {
                put("quantity", quantity)
            }

            db.update(
                "inventory",
                values,
                "item_name=?",
                arrayOf(itemName)
            )
        }

        cursor.close()

        return builder.toString()
    }

    fun getInventoryItems(): MutableList<InventoryItem> {

        val inventoryList = mutableListOf<InventoryItem>()

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM inventory",
            null
        )

        while (cursor.moveToNext()) {

            inventoryList.add(
                InventoryItem(
                    cursor.getInt(
                        cursor.getColumnIndexOrThrow("id")
                    ),
                    cursor.getString(
                        cursor.getColumnIndexOrThrow("item_name")
                    ),
                    cursor.getInt(
                        cursor.getColumnIndexOrThrow("quantity")
                    )
                )
            )
        }

        cursor.close()

        return inventoryList
    }


}