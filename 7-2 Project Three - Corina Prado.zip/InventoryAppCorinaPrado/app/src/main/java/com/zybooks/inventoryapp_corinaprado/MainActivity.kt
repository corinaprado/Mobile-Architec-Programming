package com.zybooks.inventoryapp_corinaprado

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.content.Intent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var databaseHelper: DatabaseHelper

    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText

    private lateinit var buttonLogin: Button
    private lateinit var buttonCreateAccount: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        databaseHelper = DatabaseHelper(this)

        editUsername = findViewById(R.id.editUsername)
        editPassword = findViewById(R.id.editPassword)

        buttonLogin = findViewById(R.id.buttonLogin)
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount)

        buttonCreateAccount.setOnClickListener {

            val username = editUsername.text.toString().trim()
            val password = editPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {

                Toast.makeText(
                    this,
                    "Please enter username and password",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                val success =
                    databaseHelper.addUser(username, password)

                if (success) {

                    Toast.makeText(
                        this,
                        "Account Created",
                        Toast.LENGTH_SHORT
                    ).show()

                } else {

                    Toast.makeText(
                        this,
                        "Username already exists",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        buttonLogin.setOnClickListener {

            val username = editUsername.text.toString().trim()
            val password = editPassword.text.toString().trim()

            val validUser =
                databaseHelper.validateUser(
                    username,
                    password
                )

            if (validUser) {

                Toast.makeText(
                    this,
                    "Login Successful",
                    Toast.LENGTH_SHORT
                ).show()

                startActivity(
                    Intent(
                        this,
                        InventoryActivity::class.java
                    )
                )

            } else {

                Toast.makeText(
                    this,
                    "Invalid Username or Password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}